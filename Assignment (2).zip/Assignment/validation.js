function validate() {
  let x1 = document.getElementById("firstname");
  if (x1.value == "") {
    document.getElementById("p1").innerHTML = "*Firstname should not be empty*";
    return false;
  }

  let x2 = document.getElementById("lastname");
  if (x2.value == "") {
    document.getElementById("p2").innerHTML = "*Lastname should not be empty*";
    return false;
  }

  let x3 = document.getElementById("email");
  var regEx =
    /^[A-Z0-9][A-Z0-9._%+-]{0,63}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/;
  var validEmail = regEx.test(email);
  if (x3.value == "") {
    document.getElementById("p3").innerHTML = "*Enter a valid e-mail* ";
    return false;
  }

  if (x3.value != validEmail) {
    document.getElementById("p3").innerHTML = "*This email is not valid* ";
    return false;
  } else {
    return true;
  }

  let x4 = document.getElementById("psw1");
  if (x4.value == "") {
    document.getElementById("p4").innerHTML = "*Create your password*";
    return false;
  }

  let x5 = document.getElementById("psw2");
  if (x5.value == "") {
    document.getElementById("p5").innerHTML = "*Re-type your password*";
    return false;
  }

  if (x4.value != x5.value) {
    document.getElementById("p5").innerHTML = `Password didn't match`;
  } else {
    alert("You have successfully registered");
  }
}
